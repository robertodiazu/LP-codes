package packageexample.uno;

public class ClaseGlobal {
  public String uno;
}
