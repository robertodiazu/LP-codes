package access;

import access.other_package.*;

public class Main {

  public static void main(String[] args){
    ClaseA ca; //= new ClaseA();
    ca.printVals(ca);

    // ClaseA ca2 = new ClaseA();
    // ca.printVals(ca2);

    // ClaseSubA csa = new ClaseSubA();
    // ca.printVals(ca);

    // ClaseB cb = new ClaseB();
    // cb.printVals(ca);
    //
    // ClaseC cc = new ClaseC();
    // cc.printVals(ca);

  }

}
