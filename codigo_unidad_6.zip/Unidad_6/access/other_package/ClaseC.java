package access.other_package;

import access.ClaseA;

public class ClaseC {
  public void printVals(ClaseA a){
    System.out.println(a.a);
    System.out.println(a.b);
    System.out.println(a.c);
    System.out.println(a.d);
  }
}
