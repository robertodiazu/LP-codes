package access;

class ClaseSubA extends ClaseA {

  public void printVals(){
    System.out.println(this.a);
    System.out.println(this.b);
    System.out.println(this.c);
    System.out.println(this.d);
  }
}
