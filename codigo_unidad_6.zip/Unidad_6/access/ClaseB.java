package access;

class ClaseB {

  public void printVals(ClaseA a){
    System.out.println(a.a);
    System.out.println(a.b);
    System.out.println(a.c);
    //System.out.println(a.d);
  }

}
