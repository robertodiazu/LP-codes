% En un cierto juego, existen cuatro equipos cada uno con tres integrantes:
equipo(alpha, lauren).
equipo(alpha, julia).
equipo(alpha, sean).
equipo(bravo, luke).
equipo(bravo, madeleine).
equipo(bravo, wendy).
equipo(gamma, john).
equipo(gamma, edward).
equipo(gamma, eric).
equipo(delta, virginia).
equipo(delta, nicola).
equipo(delta, caroline).

% En el juego, los distintos miembros obtienen una cierta cantidad de puntos.
puntos(lauren,-20).
puntos(julia,50).
puntos(sean,30).
puntos(luke,70).
puntos(madeleine,40).
puntos(wendy,60).
puntos(john,-10).
puntos(edward,-15).
puntos(eric,-30).
puntos(virginia,20).
puntos(nicola,15).
puntos(caroline,5).

% Escribir una regla sumar_lista(L,P), donde P es la suma de los puntajes de la lista L. 
% No puede usar sum_list para el desarrollo de esta regla.

% Escribir una regla puntaje_final(E, P), donde P es la suma de los puntos obtenidos por los integrantes del equipo E.