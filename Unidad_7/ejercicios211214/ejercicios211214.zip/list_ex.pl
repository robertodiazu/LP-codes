% Escriba los siguientes predicados

% ultimo(X,L): que determina si X es el último elemento de la lista L

% reverso(L,R): que determina si la lista R es el inverso de la lista L


% palindrome(L): que determina si la lista L es un palindrome. 
% Un palindromo puede ser leído igual hacia adelante y hacia atrás (e.g. [o,s,o], [r,a,d,a,r]).