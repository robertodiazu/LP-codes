
mas_grande(perro,hormiga).
mas_grande(elefante,hormiga).
mas_grande(elefante,perro).
mas_grande(luna, hormiga).
mas_grande(luna, perro).
mas_grande(luna, elefante).

:- op(600,xfx,mas_grande).
