vertical(seg(punto(X, _), punto(X, _))).
horizontal(seg(punto(_, Y), punto(_, Y))).
