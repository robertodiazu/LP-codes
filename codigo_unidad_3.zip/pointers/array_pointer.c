/*
Ejemplo de punteros y arreglos en C
Una variable de arreglo es basicamente un puntero constante apuntando a la
primera posicion en memoria del arreglo
*/

#include <stdio.h>

int main(){
  int a[10] = {0,1,2,3,4,5,6,7,8,9};
  int *pa;

  pa = &a[0];
  pa = a; /* hace lo mismo que la linea anterior */

  int i;
  /* los tres for hacen lo mismo */
  for (i=0; i<10; i++)
    printf("%d ",a[i]);
  printf("\n");

  for (i=0; i<10; i++)
    printf("%d ",*(pa+i));
  printf("\n");
  
  for (i=0; i<10; i++)
    printf("%d ",*(a+i));
  printf("\n");

  return 0;
}
