package string;

public class StringExample {
    public static void main(String[] args) {
      String palindrome = "reconocer";        //referencia String
      char[] arregloHola = {'h','o','l','a'}; //arreglo
      String stringHola = new String(arregloHola);
      System.out.println(palindrome);

    }
}
