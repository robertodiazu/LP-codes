package interfaceexample;

public interface CustomInterface {
  public void metodoAImplementar();

  public int otroMetodoMas(int nombreParametro);
}
