package packageexample.dos;


public class ClaseGlobal {
  public String dos;
}
