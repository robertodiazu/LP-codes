package inheritance;

class SubClase extends SuperClase{

  public void initMensaje(){
    super.initMensaje();    
    mensaje += " y hola Edmundo inmundo";
  }

  public void addToMensaje(){
    mensaje += " y hola Edmundo inmundo";
  }

}
