package inheritance;

public class SuperClase{
  protected String mensaje = "";

  public String getMensaje(){
    return mensaje;
  }

  public void initMensaje(){
    mensaje = "Hello World";
  }

}
