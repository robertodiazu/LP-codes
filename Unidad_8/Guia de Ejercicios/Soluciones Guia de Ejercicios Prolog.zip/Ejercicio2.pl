codigo(4,x):-!.
codigo(8,y):-!.
codigo(_,z).
